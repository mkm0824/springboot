package com.coding404.myweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMyWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
